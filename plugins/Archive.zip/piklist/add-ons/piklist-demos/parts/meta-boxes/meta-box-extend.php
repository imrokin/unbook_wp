<?php
/*
Title: Extend Piklist
Post Type: piklist_demo
Order: 100
Lock: true
Flow: Demo Workflow
Tab: Extend
*/
?>

<p>
  <?php _e('Extend your own meta-boxes generated in piklist!', 'piklist-demos'); ?>
</p>
