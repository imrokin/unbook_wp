<?php
/*
Title: Post Formats... extended by Piklist
Post Type: piklist_demo,page
Flow: Demo Workflow
Tab: Extend
Meta Box: true
Extend: formatdiv
Extend Method: after
*/

  piklist('shared/code-locater', array(
    'location' => __FILE__
    ,'type' => 'Meta Box'
  ));