<?php
/*  
Title: Lists
Class: custom-class-1 custom-class-2
Width: 720
*/

  echo $before_widget;

  echo $before_title;

  echo $after_title;

  piklist::pre($settings);

  echo $after_widget;