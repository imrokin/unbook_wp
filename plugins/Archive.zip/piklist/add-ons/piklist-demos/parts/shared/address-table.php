<p>
  <?php echo $data['address_1']; ?>
  <?php echo $data['address_2']; ?>,
  <?php echo $data['city']; ?>,
  <?php echo $data['state']; ?>,
  <?php echo $data['postal_code']; ?>
</p>