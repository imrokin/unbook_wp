
<div style="display: none !important;">
  
  <?php 
    wp_editor(null, 'piklist-editor-proxy', array(
      'teeny' => true,
      'tinymce' => array(
        'wp_skip_init' => true
      )
    )); 
  ?>

</div>
