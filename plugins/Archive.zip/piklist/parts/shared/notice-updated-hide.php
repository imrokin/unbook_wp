
<style type="text/css">
  
  .wrap div.updated {
    display: none !important;
  }
  
</style>
