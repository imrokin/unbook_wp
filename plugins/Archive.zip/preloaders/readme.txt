=== Preloaders ===
Contributors: shapedplugin
Donate link: http://shapedplugin.com
Tags: preloader, free preloaders, preloader plugin, smooth preloader, nice preloader, best preloader
Requires at least: 4.0
Tested up to: 4.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin sets Preloader in your website.

== Description ==

Preloaders is a nice and smooth preloader Wordpress plugin which you can install in your website in the easiest way.


== Installation ==

1. Upload plugin directory to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Preloaders’ menu in WordPress.


== Screenshots ==


== Changelog ==

= 1.0 =

== Upgrade Notice ==

= 1.0 =