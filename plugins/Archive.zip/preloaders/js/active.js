jQuery(window).load(function() {
	jQuery("#loading-center").delay(600).fadeOut(600);
	jQuery("#loading").delay(1200).fadeOut(800);
});
