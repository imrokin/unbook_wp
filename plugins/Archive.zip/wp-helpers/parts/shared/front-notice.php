<div id="wp-helpers-notice" class="alert alert-<?php echo $type; ?>">

  <span>

    <?php echo $message; ?>

</span>
    
</div>