<!-- WP Helpers -->
<style type="text/css">
  .login h1 a {
    background: url(<?php echo esc_url_raw($image[0]); ?>) no-repeat top center;
    width: <?php echo $width; ?>px;
    height: <?php echo $height; ?>px;
		background-size: <?php echo $width; ?>px <?php echo $height; ?>px;
  }
</style>
