<!DOCTYPE>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US" xml:lang="en-US">
<head profile="http://gmpg.org/xfn/11">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Login Warning</title>
	<meta name="robots" content="noodp,noydir" />
	<style>
	#wrapper {
		width: 100%;
		margin: 20px auto;
	}
	</style>

</head>
<body>
	<div id="wrapper">
	<h1>Login Warning</h1>
	<p>There was an issue with your log in. Your user account has logged in recently from a different location.</p>
	</div>
</body>
</html>
